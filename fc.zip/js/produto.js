const WHATSAPP_NUMERO = "5511989065804";

/* ===============================
   CARREGAMENTO DO PRODUTO
================================ */
document.addEventListener("DOMContentLoaded", async () => {
  atualizarContador();

  const params = new URLSearchParams(window.location.search);
  const idProduto = params.get("id");

  const info = document.getElementById("info-produto");

  if (!idProduto) {
    info.innerHTML = "<p>Produto não encontrado.</p>";
    return;
  }

  try {
    const resposta = await fetch("/produtos/florescer_chique_produtos.json");
    const produtos = await resposta.json();

    const produto = produtos.find(p => String(p.id) === String(idProduto));

    if (!produto) {
      info.innerHTML = "<p>Produto não encontrado.</p>";
      return;
    }

    exibirDetalhesProduto(produto);

  } catch (erro) {
    console.error("Erro:", erro);
    info.innerHTML = "<p>Erro ao carregar produto.</p>";
  }
});

/* ===============================
   EXIBIÇÃO DO PRODUTO
================================ */
function exibirDetalhesProduto(produto) {
  const imagensContainer = document.getElementById("imagens-produto");
  const infoContainer = document.getElementById("info-produto");

  imagensContainer.innerHTML = `
    <div class="carrossel">
      <button class="anterior">&#10094;</button>
      <div class="imagens">
        ${produto.imagens.map((img, i) => `
          <img src="${img}" 
               class="imagem-carrossel ${i === 0 ? "ativa" : ""}" 
               alt="${produto.nome}">
        `).join("")}
      </div>
      <button class="proximo">&#10095;</button>
    </div>
  `;

  infoContainer.innerHTML = `
    <p class="produto-id">Código: ${produto.id}</p>
    <h2 class="produto-titulo">${produto.nome}</h2>
    <p class="produto-descricao">${produto.descricao}</p>
    <p class="produto-preco"><strong>R$ ${produto.preco.toFixed(2)}</strong></p>

    <div class="acoes-produto">
      <button class="botao-sacola">👜 Adicionar à sacola</button>
    </div>
  `;

  document.querySelector(".botao-sacola").addEventListener("click", () => {
    adicionarProduto(produto);
    alert("Produto adicionado à sacola 👜");
  });

  configurarCarrossel();
}

/* ===============================
   CARROSSEL
================================ */
function configurarCarrossel() {
  let indice = 0;
  const imagens = document.querySelectorAll(".imagem-carrossel");

  function mostrar(i) {
    imagens.forEach((img, idx) =>
      img.classList.toggle("ativa", idx === i)
    );
  }

  document.querySelector(".anterior").onclick = () => {
    indice = (indice - 1 + imagens.length) % imagens.length;
    mostrar(indice);
  };

  document.querySelector(".proximo").onclick = () => {
    indice = (indice + 1) % imagens.length;
    mostrar(indice);
  };
}

/* ===============================
   SACOLA (COMPATÍVEL COM sacola.js)
================================ */

function obterSacola() {
  return JSON.parse(localStorage.getItem("sacola")) || [];
}

function salvarSacola(sacola) {
  localStorage.setItem("sacola", JSON.stringify(sacola));
  atualizarContador();
}

function adicionarProduto(produto) {
  const sacola = obterSacola();

  const existente = sacola.find(item => item.id === produto.id);

  if (existente) {
    existente.quantidade += 1;
  } else {
    sacola.push({
      id: produto.id,
      nome: produto.nome,
      preco: produto.preco,
      imagem: produto.imagem, // 👈 imagem principal
      quantidade: 1
    });
  }

  salvarSacola(sacola);
}

function atualizarContador() {
  const contador = document.getElementById("contador-sacola");
  if (!contador) return;

  const sacola = obterSacola();
  const totalItens = sacola.reduce((soma, item) => soma + item.quantidade, 0);

  contador.innerText = totalItens;
}
